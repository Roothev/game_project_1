﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Schowaj_z_gi : MonoBehaviour {

    public GameObject cos;
	// Use this for initialization
	void Start () {
        cos.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
